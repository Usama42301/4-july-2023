from machine import Pin, ADC 
pot=ADC(Pin(34, Pin.IN))
led=(Pin(15, Pin.OUT))

while True:
  val=pot.read()
  print(val)

  led.value(val)
